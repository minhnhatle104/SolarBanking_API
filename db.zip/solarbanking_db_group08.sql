-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: final_solarbanking
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `bank_code` char(8) NOT NULL,
  `bank_name` varchar(20) DEFAULT NULL,
  `public_key` text DEFAULT NULL,
  `encoding_type` enum('RSA','PGP') DEFAULT NULL,
  PRIMARY KEY (`bank_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES ('SLB','Solar Bank',NULL,NULL),('TXB','Tai Xiu Bank','-----BEGIN PUBLIC KEY-----\r\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCBaupoGFgzyEg3itWMC6LijzHW\r\nWxeIyHz/KdIxq0KfugzvPthGnBn3FtZn+XrPQ10Vv5UTMhOUfNLg/QOOOfXVGmXx\r\nc8y1BOW8SBEAEK6WWJ9O6rORt/u2ShbxrPpVRef3YvZG/0Gq3kpi0LaqMFihj5lE\r\n3IOJp1zle/AAfKoR9wIDAQAB\r\n-----END PUBLIC KEY-----','RSA');
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banking_account`
--

DROP TABLE IF EXISTS `banking_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banking_account` (
  `account_number` varchar(15) NOT NULL,
  `balance` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `bank_code` char(8) NOT NULL,
  `is_spend_account` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`account_number`),
  KEY `fk_bankingaccount_user` (`user_id`),
  KEY `fk_bankingaccount_bank` (`bank_code`),
  CONSTRAINT `fk_bankingaccount_bank` FOREIGN KEY (`bank_code`) REFERENCES `bank` (`bank_code`),
  CONSTRAINT `fk_bankingaccount_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banking_account`
--

LOCK TABLES `banking_account` WRITE;
/*!40000 ALTER TABLE `banking_account` DISABLE KEYS */;
INSERT INTO `banking_account` VALUES ('00733896',4290000,71,'SLB',1),('01325183',1360000,40,'SLB',1),('06929692',200000,46,'SLB',1),('07788201',14090000,38,'SLB',1),('111231424',5000000,34,'SLB',0),('17444489',9601000,58,'SLB',1),('18360057',50000,44,'SLB',1),('18713328',4555000,69,'SLB',1),('20099123',100000,45,'SLB',1),('23875338674',0,57,'TXB',1),('28069884',10033000,34,'SLB',-1),('29718009',100000,49,'SLB',1),('32452091',50000,43,'SLB',1),('32709550',310000,37,'SLB',1),('35057856',1550000,35,'SLB',1),('36871570986',0,NULL,'TXB',1),('38424434',50000,48,'SLB',1),('44672774950',0,NULL,'TXB',1),('456547476',200000000,34,'SLB',0),('48750494',400000,36,'SLB',1),('49578221111',0,NULL,'TXB',1),('49861159',5000,50,'SLB',1),('51283119',5150000,70,'SLB',1),('59025838490',0,73,'TXB',1),('68052570',121000,41,'SLB',1),('71873611',397000,56,'SLB',1),('81627401',759000,59,'SLB',1),('83181029',200000,42,'SLB',1),('83593566',350000,51,'SLB',1),('83901888',61000,47,'SLB',1),('85202767',4685000,60,'SLB',1),('86381372076',0,NULL,'TXB',1),('87446423777',0,72,'TXB',1),('89143092',400000,52,'SLB',1),('89809675',200000,54,'SLB',1),('90562859',350000,39,'SLB',1),('92883447',2000000,55,'SLB',1),('94869607',300000,53,'SLB',1),('SLB',0,NULL,'SLB',1);
/*!40000 ALTER TABLE `banking_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debt_list`
--

DROP TABLE IF EXISTS `debt_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `debt_list` (
  `debt_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `debt_account_number` varchar(15) NOT NULL,
  `debt_amount` int(11) NOT NULL,
  `debt_message` varchar(50) NOT NULL,
  `paid_transaction_id` int(11) DEFAULT NULL,
  `debt_status` enum('PAID','NOT PAID','CANCEL') NOT NULL,
  `debt_cancel_message` varchar(50) NOT NULL,
  `debt_created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`debt_id`),
  KEY `fk_debtlist_user` (`user_id`),
  KEY `fk_debtlist_bankaccount` (`debt_account_number`),
  KEY `fk_debtlist_transaction` (`paid_transaction_id`),
  CONSTRAINT `fk_debtlist_bankaccount` FOREIGN KEY (`debt_account_number`) REFERENCES `banking_account` (`account_number`),
  CONSTRAINT `fk_debtlist_transaction` FOREIGN KEY (`paid_transaction_id`) REFERENCES `transaction` (`transaction_id`),
  CONSTRAINT `fk_debtlist_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debt_list`
--

LOCK TABLES `debt_list` WRITE;
/*!40000 ALTER TABLE `debt_list` DISABLE KEYS */;
INSERT INTO `debt_list` VALUES (1,34,'28069884',500000,'Taxi Fee To TRAN HUNG DAO',75,'PAID','','2022-12-28 13:22:48'),(4,38,'28069884',500000,'JW Marriot Dinner',NULL,'NOT PAID','','2023-01-01 11:53:26'),(5,55,'28069884',160000,'Movie Ticket (Avatar 2)',NULL,'NOT PAID','','2022-12-30 15:07:04'),(6,41,'28069884',350000,'Buffet Hana (already discount 10%) ^^',NULL,'NOT PAID','','2023-01-01 11:19:00'),(7,56,'48750494',400000,'tra tien taoooo',NULL,'NOT PAID','','2023-01-01 10:49:55'),(8,56,'32452091',160000,'Movie Ticket ',NULL,'CANCEL','Nham nguoi','2023-01-10 14:39:03'),(9,56,'28069884',400000,'bvbvbvbvbv',NULL,'CANCEL','Nham nguoi','2023-01-10 14:38:58'),(10,56,'01325183',30000,'fsdfsdfsdfsdfsdf',NULL,'CANCEL','Nham nguoi','2023-01-10 14:38:45'),(11,58,'71873611',50000,'Tiền bánh mìiiii',105,'PAID','','2023-01-07 09:02:24'),(12,56,'17444489',30000,'Gas',106,'PAID','','2023-01-07 09:09:04'),(13,56,'17444489',28000,'Buffet Hana',107,'PAID','','2023-01-07 09:56:48'),(14,58,'85202767',20000,'Banh Mi',114,'PAID','','2023-01-09 11:11:38'),(15,58,'85202767',30000,'Hhe',NULL,'NOT PAID','','2023-01-09 11:14:30'),(16,56,'71873611',20000,'Tien banh baooo',NULL,'CANCEL','Have No Money','2023-01-10 14:32:41'),(17,58,'71873611',20000,'Hahahaha',NULL,'CANCEL','Khong Co Tien','2023-01-10 14:38:21'),(18,58,'71873611',50000,'zzzzzz',115,'NOT PAID','','2023-01-10 14:40:29'),(19,56,'18713328',50000,'Tra tien taooo',121,'PAID','','2023-01-11 13:11:45'),(24,56,'00733896',50000,'Tien an sang',135,'PAID','','2023-01-12 15:32:43');
/*!40000 ALTER TABLE `debt_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forget_password_history`
--

DROP TABLE IF EXISTS `forget_password_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forget_password_history` (
  `user_id` int(11) NOT NULL,
  `reset_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `otp_code` char(6) NOT NULL,
  `old_password` varchar(128) NOT NULL,
  `new_password` varchar(128) NOT NULL,
  PRIMARY KEY (`user_id`,`reset_at`),
  CONSTRAINT `fk_forgetpasswordhistory_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forget_password_history`
--

LOCK TABLES `forget_password_history` WRITE;
/*!40000 ALTER TABLE `forget_password_history` DISABLE KEYS */;
INSERT INTO `forget_password_history` VALUES (34,'2022-12-22 17:24:48','987210','$2b$10$YNJ38BDf9eWm7Ux1b6E5P.ZS2a1RZ9YXkoXV0kL5V8IstzkuCFxM6','$2b$10$YNJ38BDf9eWm7Ux1b6E5P.cl4R0F/A0fpKkin0zvVsP3J7grDI6Pq'),(34,'2022-12-22 17:25:27','390622','$2b$10$YNJ38BDf9eWm7Ux1b6E5P.ZS2a1RZ9YXkoXV0kL5V8IstzkuCFxM6','$2b$10$YNJ38BDf9eWm7Ux1b6E5P.ZS2a1RZ9YXkoXV0kL5V8IstzkuCFxM6'),(34,'2023-01-01 12:50:55','261076','$2b$10$YNJ38BDf9eWm7Ux1b6E5P.ZS2a1RZ9YXkoXV0kL5V8IstzkuCFxM6','$2b$10$0dwBeTTqTdYSRKajJXG6Je2o.EZD/kOezO2DpK7DcucVXE.74R6Cu'),(34,'2023-01-02 10:03:31','546366','',''),(34,'2023-01-02 10:04:46','292658','','');
/*!40000 ALTER TABLE `forget_password_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `debt_id` int(11) DEFAULT NULL,
  `notification_message` varchar(200) NOT NULL,
  `is_seen` tinyint(1) NOT NULL,
  `notification_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `notification_title` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `fk_notification_user` (`user_id`),
  KEY `fk_notification_transaction` (`transaction_id`),
  KEY `fk_notification_debtlist` (`debt_id`),
  CONSTRAINT `fk_notification_debtlist` FOREIGN KEY (`debt_id`) REFERENCES `debt_list` (`debt_id`),
  CONSTRAINT `fk_notification_transaction` FOREIGN KEY (`transaction_id`) REFERENCES `transaction` (`transaction_id`),
  CONSTRAINT `fk_notification_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (35,34,NULL,5,'Movie Ticket (Avatar 2)',1,'2022-12-30 15:08:40','Payyyy!'),(36,34,NULL,4,'I hope i can get it back on Friday <3',1,'2022-12-30 15:15:00','JW Mariot Dinner'),(37,34,NULL,1,'Taxi Fee remember to pay me back bitchhh',1,'2022-12-30 15:32:25','Heyy bitchhhh'),(38,34,NULL,6,'I am poorrrrr, just remember to pay it back',0,'2023-01-01 11:19:41','Buffet Hana'),(39,34,NULL,9,'You have a new debt with amount 400,000 VND from L',0,'2023-01-05 15:56:50','Debt Reminder'),(40,40,NULL,10,'You have a new debt with amount 30,000 VND from La',0,'2023-01-07 05:05:31','Debt Reminder'),(41,56,NULL,11,'You have a new debt with amount 50,000 VND from Nguyen An Hung - 17444489',1,'2023-01-07 05:46:32','Debt Reminder'),(42,58,105,11,'Debt code 11 has been paid by Lam Bao Ngoc - 71873611.',1,'2023-01-07 09:02:24','Debt Payment'),(43,58,NULL,12,'You have a new debt with amount 30,000 VND from Lam Bao Ngoc - 71873611',1,'2023-01-07 09:08:02','Debt Reminder'),(44,56,106,12,'Debt code 12 has been paid by Nguyen An Hung - 17444489.',1,'2023-01-07 09:09:04','Debt Payment'),(45,58,NULL,13,'You have a new debt with amount 28,000 VND from Lam Bao Ngoc - 71873611',1,'2023-01-07 09:55:48','Debt Reminder'),(46,56,107,13,'Debt code 13 has been paid by Nguyen An Hung - 17444489.',1,'2023-01-07 09:56:48','Debt Payment'),(47,60,NULL,14,'You have a new debt with amount 20,000 VND from Nguyen An Hung - 17444489',1,'2023-01-09 11:10:42','Debt Reminder'),(48,58,114,14,'Debt code 14 has been paid by Le Minh Thu - 85202767.',1,'2023-01-09 11:11:38','Debt Payment'),(49,60,NULL,15,'You have a new debt with amount 30,000 VND from Nguyen An Hung - 17444489',0,'2023-01-09 11:14:30','Debt Reminder'),(50,56,NULL,16,'You have a new debt with amount 20,000 VND from Lam Bao Ngoc - 71873611',1,'2023-01-09 12:42:27','Debt Reminder'),(51,56,NULL,16,'Debt code 16 has been cancelled by Lam Bao Ngoc - 71873611 with message: Have No Money',1,'2023-01-10 14:32:41','Debt Cancellation'),(52,56,NULL,17,'You have a new debt with amount 20,000 VND from Nguyen An Hung - 17444489',1,'2023-01-10 14:37:45','Debt Reminder'),(53,58,NULL,17,'Debt code 17 has been cancelled by Lam Bao Ngoc - undefined with message: Khong Co Tien',1,'2023-01-10 14:38:21','Debt Cancellation'),(54,40,NULL,10,'Debt code 10 has been cancelled by Lam Bao Ngoc - 71873611 with message: Nham nguoi',0,'2023-01-10 14:38:45','Debt Cancellation'),(55,34,NULL,9,'Debt code 9 has been cancelled by Lam Bao Ngoc - 71873611 with message: Nham nguoi',0,'2023-01-10 14:38:58','Debt Cancellation'),(56,43,NULL,8,'Debt code 8 has been cancelled by Lam Bao Ngoc - 71873611 with message: Nham nguoi',0,'2023-01-10 14:39:03','Debt Cancellation'),(57,56,NULL,18,'You have a new debt with amount 50,000 VND from Nguyen An Hung - 17444489',1,'2023-01-10 14:40:09','Debt Reminder'),(58,69,NULL,19,'You have a new debt with amount 50,000 VND from Lam Bao Ngoc - 71873611',1,'2023-01-11 13:10:56','Debt Reminder'),(59,56,121,19,'Debt code 19 has been paid by Dang Duy Khang - 18713328.',1,'2023-01-11 13:11:45','Debt Payment'),(66,71,NULL,24,'You have a new debt with amount 50,000 VND from Lam Bao Ngoc - 71873611',1,'2023-01-12 15:32:07','Debt Reminder'),(67,56,135,24,'Debt code 24 has been paid by Ho Hoang Bach - 00733896.',1,'2023-01-12 15:32:43','Debt Payment');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipient_list`
--

DROP TABLE IF EXISTS `recipient_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recipient_list` (
  `user_id` int(11) NOT NULL,
  `account_number` varchar(15) NOT NULL,
  `nick_name` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`,`account_number`),
  KEY `fk_recipientlist_bankingaccount` (`account_number`),
  CONSTRAINT `fk_recipientlist_bankingaccount` FOREIGN KEY (`account_number`) REFERENCES `banking_account` (`account_number`),
  CONSTRAINT `fk_recipientlist_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipient_list`
--

LOCK TABLES `recipient_list` WRITE;
/*!40000 ALTER TABLE `recipient_list` DISABLE KEYS */;
INSERT INTO `recipient_list` VALUES (34,'01325183','asdasd'),(34,'07788201','asdasd'),(58,'44672774950','Hahaa'),(58,'87446423777','hoang_giang'),(59,'28069884','Khuong'),(59,'36871570986','OOO..'),(59,'49578221111','Banhbaoo'),(59,'59025838490','HoangNha'),(59,'71873611','Lam Bao Ngoc'),(59,'86381372076','Kokoko'),(60,'71873611','haha'),(60,'94869607','khang_mai'),(69,'83593566','Lam Hoang Tuan'),(69,'89809675','Hahahaha'),(71,'48750494','Kakaa'),(71,'90562859','Le Phuong Mai');
/*!40000 ALTER TABLE `recipient_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `src_account_number` varchar(15) NOT NULL,
  `des_account_number` varchar(15) NOT NULL,
  `transaction_amount` int(11) NOT NULL,
  `otp_code` char(6) NOT NULL,
  `transaction_message` varchar(50) NOT NULL,
  `pay_transaction_fee` enum('SRC','DES') NOT NULL,
  `is_success` tinyint(1) NOT NULL,
  `transaction_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `transaction_type` int(11) NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `fk_transaction_srcbankaccount` (`src_account_number`),
  KEY `fk_transaction_desbankaccount` (`des_account_number`),
  KEY `fk_transaction_transactiontype` (`transaction_type`),
  CONSTRAINT `fk_transaction_desbankaccount` FOREIGN KEY (`des_account_number`) REFERENCES `banking_account` (`account_number`),
  CONSTRAINT `fk_transaction_srcbankaccount` FOREIGN KEY (`src_account_number`) REFERENCES `banking_account` (`account_number`),
  CONSTRAINT `fk_transaction_transactiontype` FOREIGN KEY (`transaction_type`) REFERENCES `transaction_type` (`transaction_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (2,'SLB','07788201',20000,'000000','SOLAR BANKING TRANSFER 20,000 VND at 2022-12-16T09','',1,'2022-12-16 09:29:43',1),(3,'SLB','28069884',500000,'000000','SOLAR BANKING TRANSFER 500,000 VND at 2022-12-16T0','',1,'2022-12-16 09:30:14',1),(4,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T11','',1,'2022-12-16 11:20:26',1),(5,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T11','',1,'2022-12-16 11:22:11',1),(6,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T11','',1,'2022-12-16 11:22:13',1),(7,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T11','',1,'2022-12-16 11:22:28',1),(8,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T11','',1,'2022-12-16 11:22:39',1),(9,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T11','',1,'2022-12-16 11:24:18',1),(10,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T11','',1,'2022-12-16 11:28:36',1),(11,'SLB','28069884',500000,'000000','SOLAR BANKING TRANSFER 500,000 VND at 2022-12-16T1','',1,'2022-12-16 11:34:50',1),(12,'SLB','07788201',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T11','',1,'2022-12-16 11:36:02',1),(13,'SLB','07788201',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T11','',1,'2022-12-16 11:36:56',1),(14,'SLB','07788201',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T11','',1,'2022-12-16 11:37:45',1),(15,'SLB','07788201',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T11','',1,'2022-12-16 11:38:36',1),(16,'SLB','07788201',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T11','',1,'2022-12-16 11:39:11',1),(17,'SLB','07788201',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T11','',1,'2022-12-16 11:41:08',1),(18,'SLB','07788201',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T11','',1,'2022-12-16 11:41:46',1),(19,'SLB','07788201',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T11','',1,'2022-12-16 11:44:32',1),(20,'SLB','07788201',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T11','',1,'2022-12-16 11:44:42',1),(21,'SLB','35057856',500000,'000000','SOLAR BANKING TRANSFER 500,000 VND at 2022-12-16T1','',1,'2022-12-16 11:45:52',1),(22,'SLB','35057856',1000000,'000000','SOLAR BANKING TRANSFER 1,000,000 VND at 2022-12-16','',1,'2022-12-16 11:51:42',1),(23,'SLB','28069884',1000000,'000000','SOLAR BANKING TRANSFER 1,000,000 VND at 2022-12-16','',1,'2022-12-16 11:53:40',1),(24,'SLB','28069884',5000000,'000000','SOLAR BANKING TRANSFER 5,000,000 VND at 2022-12-16','',1,'2022-12-16 11:55:57',1),(25,'SLB','28069884',20000,'000000','SOLAR BANKING TRANSFER 20,000 VND at 2022-12-16T12','',1,'2022-12-16 12:20:51',1),(26,'SLB','29718009',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-16T12','',1,'2022-12-16 12:23:17',1),(27,'SLB','07788201',1000000,'000000','SOLAR BANKING TRANSFER 1,000,000 VND at 2022-12-16','',1,'2022-12-16 12:40:31',1),(28,'SLB','28069884',1000000,'000000','SOLAR BANKING TRANSFER 1,000,000 VND at 2022-12-16','',1,'2022-12-16 12:41:03',1),(29,'SLB','28069884',1000000,'000000','SOLAR BANKING TRANSFER 1,000,000 VND at 2022-12-16','',1,'2022-12-16 12:47:21',1),(30,'SLB','07788201',500000,'000000','SOLAR BANKING TRANSFER 500,000 VND at 2022-12-16T1','',1,'2022-12-16 12:49:03',1),(31,'SLB','07788201',500000,'000000','SOLAR BANKING TRANSFER 500,000 VND at 2022-12-16T1','',1,'2022-12-16 12:49:30',1),(32,'SLB','07788201',500000,'000000','SOLAR BANKING TRANSFER 500,000 VND at 2022-12-16T1','',1,'2022-12-16 12:49:32',1),(33,'SLB','07788201',500000,'000000','SOLAR BANKING TRANSFER 500,000 VND at 2022-12-16T1','',1,'2022-12-16 12:50:28',1),(34,'SLB','07788201',20000,'000000','SOLAR BANKING TRANSFER 20,000 VND at 2022-12-16T12','',1,'2022-12-16 12:51:44',1),(35,'SLB','07788201',10000000,'000000','SOLAR BANKING TRANSFER 10,000,000 VND at 2022-12-1','',1,'2022-12-16 12:53:48',1),(36,'SLB','07788201',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T12','',1,'2022-12-16 12:54:30',1),(37,'SLB','07788201',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T12','',1,'2022-12-16 12:55:02',1),(38,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T12','',1,'2022-12-16 12:55:48',1),(39,'SLB','32709550',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T12','',1,'2022-12-16 12:55:56',1),(40,'SLB','32709550',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T12','',1,'2022-12-16 12:56:01',1),(41,'SLB','32709550',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T12','',1,'2022-12-16 12:56:05',1),(42,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T12','',1,'2022-12-16 12:56:12',1),(43,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T12','',1,'2022-12-16 12:56:24',1),(44,'SLB','07788201',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T14','',1,'2022-12-16 14:28:41',1),(45,'SLB','07788201',30000,'000000','SOLAR BANKING TRANSFER 30,000 VND at 2022-12-16T14','',1,'2022-12-16 14:41:08',1),(46,'SLB','28069884',750000,'000000','SOLAR BANKING TRANSFER 750,000 VND at 2022-12-16T1','',1,'2022-12-16 14:41:18',1),(47,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-16T14','',1,'2022-12-16 14:50:56',1),(48,'SLB','28069884',500000,'000000','SOLAR BANKING TRANSFER 500,000 VND at 2022-12-16T1','',1,'2022-12-16 14:51:55',1),(49,'01325183','20099123',71000,'099867','50/50 Lunch Meal','SRC',1,'2022-12-17 13:30:08',2),(50,'01325183','32452091',200000,'555555','Movie ticket and popcorn','DES',1,'2022-12-17 13:31:02',2),(51,'01325183','83901888',150000,'333333','New Balance 237 Brown Grey','DES',1,'2022-12-17 13:31:46',2),(52,'28069884','01325183',40000,'111111','Starbucks Drink ','DES',1,'2022-12-17 13:32:19',1),(53,'01325183','49861159',550000,'111111','Banh Mi Hai Ba Trung','DES',1,'2022-12-17 13:33:01',1),(54,'18360057','01325183',71000,'099867','ONEUS Museum Charge','DES',1,'2022-12-17 13:33:45',1),(55,'32709550','01325183',635000,'454545','Repair Gucci Layout Shoe','DES',1,'2022-12-17 13:47:57',1),(56,'01325183','06929692',300000,'987086','Purchase Buffet Hana','DES',1,'2022-12-17 13:47:57',1),(57,'SLB','01325183',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-17T14','',1,'2022-12-17 14:53:50',1),(58,'SLB','01325183',200000,'000000','SOLAR BANKING TRANSFER 200,000 VND at 2022-12-17T1','',1,'2022-12-17 14:53:56',1),(59,'SLB','01325183',500000,'000000','SOLAR BANKING TRANSFER 500,000 VND at 2022-12-17T1','',1,'2022-12-17 14:54:03',1),(60,'SLB','01325183',600000,'000000','SOLAR BANKING TRANSFER 600,000 VND at 2022-12-17T1','',1,'2022-12-17 14:54:17',1),(61,'07788201','28069884',45000,'090909','Dim sum 18-12 thanks.','SRC',1,'2022-12-18 16:10:53',1),(62,'68052570','28069884',800000,'342246','Skincare Retinol Dha + Co Mem Homelab','DES',1,'2022-12-18 16:10:53',2),(63,'83901888','28069884',40000,'452215','Toai gui tien banh bao + mi goi Familymart','DES',1,'2022-12-18 16:10:53',2),(64,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-19T13','',1,'2022-12-19 13:44:01',1),(65,'SLB','28069884',100000,'000000','SOLAR BANKING TRANSFER 100,000 VND at 2022-12-19T1','',1,'2022-12-19 13:47:07',1),(66,'SLB','28069884',100000,'000000','SOLAR BANKING TRANSFER 100,000 VND at 2022-12-19T1','',1,'2022-12-19 14:26:23',1),(67,'SLB','07788201',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-19T14','',1,'2022-12-19 14:32:44',1),(68,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-22T15','',1,'2022-12-22 15:44:32',1),(69,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-22T15','',1,'2022-12-22 15:45:02',1),(70,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-22T17','',1,'2022-12-22 17:20:05',1),(71,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-22T17','',1,'2022-12-22 17:20:09',1),(72,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-23T03','',1,'2022-12-23 03:56:39',1),(73,'SLB','28069884',50000,'000000','SOLAR BANKING TRANSFER 50,000 VND at 2022-12-23T03','',1,'2022-12-23 03:56:49',1),(74,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-28T09','',1,'2022-12-28 09:46:45',1),(75,'28069884','83901888',11000,'446825','Parking Fee - Khuong','SRC',1,'2022-12-28 10:00:13',1),(76,'28069884','68052570',36000,'123316','Bun Bo Hue ','DES',1,'2022-12-28 10:02:19',1),(77,'28069884','49861159',10000,'618277','Tien Gui Xe','DES',1,'2022-12-28 10:04:28',1),(78,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2022-12-28T11','',1,'2022-12-28 11:53:58',1),(79,'28069884','01325183',30000,'487969','Banh bao trung muoi 2 trung muoi.','SRC',0,'2022-12-30 07:31:09',1),(80,'28069884','32709550',30000,'547317','Banh bao 2 trung muoi','SRC',1,'2022-12-30 07:37:57',1),(81,'71873611','28069884',20000,'765207','Boba Poppppp','DES',1,'2023-01-01 11:13:29',1),(82,'28069884','71873611',1000000,'584410','Li xi nam moi Happy New Year','SRC',1,'2023-01-01 11:22:00',1),(83,'28069884','71873611',35000,'248215','Toothbrushhhh','SRC',1,'2023-01-01 11:29:33',1),(84,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2023-01-01T12','',1,'2023-01-01 12:06:09',1),(86,'SLB','28069884',10000,'000000','SOLAR BANKING TRANSFER 10,000 VND at 2023-01-02T10','',1,'2023-01-02 10:02:35',1),(89,'SLB','17444489',50000,'000000','Initial Balance','',1,'2023-01-07 05:35:16',1),(99,'SLB','81627401',50000,'000000','Initial Balance','',1,'2023-01-07 07:46:34',1),(100,'SLB','81627401',5000000,'000000','SOLAR BANKING TRANSFER 5,000,000 VND at 2023-01-07','',1,'2023-01-07 07:46:45',1),(102,'81627401','71873611',30000,'871802','Transfer Money','SRC',1,'2023-01-07 07:48:56',1),(103,'81627401','71873611',200000,'438233','Transfer Money','SRC',1,'2023-01-07 07:50:02',1),(104,'81627401','28069884',300000,'629768','Transfer Money','SRC',1,'2023-01-07 07:51:22',1),(105,'71873611','17444489',50000,'826617','','DES',1,'2023-01-07 09:02:24',2),(106,'17444489','71873611',30000,'506801','','DES',1,'2023-01-07 09:09:04',2),(107,'17444489','71873611',28000,'254658','','DES',1,'2023-01-07 09:56:48',2),(109,'SLB','85202767',150000,'000000','Initial Balance','',1,'2023-01-09 11:00:01',1),(110,'SLB','85202767',5000000,'000000','SOLAR BANKING TRANSFER 5,000,000 VND at 2023-01-09','',1,'2023-01-09 11:00:42',1),(111,'85202767','94869607',100000,'668002','Transfer Money','SRC',1,'2023-01-09 11:01:48',1),(112,'85202767','94869607',150000,'010403','Transfer Money','SRC',1,'2023-01-09 11:06:01',1),(113,'85202767','71873611',150000,'947050','Transfer Money','SRC',1,'2023-01-09 11:07:34',1),(114,'85202767','17444489',20000,'212350','','SRC',1,'2023-01-09 11:11:38',2),(115,'71873611','17444489',50000,'577486','','SRC',0,'2023-01-10 14:45:29',2),(116,'SLB','18713328',100000,'000000','Initial Balance','',1,'2023-01-11 13:05:48',1),(117,'SLB','18713328',5000000,'000000','SOLAR BANKING TRANSFER 5,000,000 VND at 2023-01-11','',1,'2023-01-11 13:06:05',1),(118,'18713328','83593566',100000,'893963','Transfer Money','SRC',1,'2023-01-11 13:07:10',1),(119,'18713328','83593566',200000,'705267','Transfer Money','SRC',1,'2023-01-11 13:08:04',1),(120,'18713328','89809675',150000,'694871','Transfer Money','SRC',1,'2023-01-11 13:09:15',1),(121,'18713328','71873611',50000,'033026','','SRC',1,'2023-01-11 13:11:45',2),(123,'SLB','51283119',50000,'000000','Initial Balance','',1,'2023-01-12 14:23:58',1),(124,'SLB','51283119',5000000,'000000','SOLAR BANKING TRANSFER 5,000,000 VND at 2023-01-12','',1,'2023-01-12 14:24:28',1),(125,'SLB','00733896',100000,'000000','Initial Balance','',1,'2023-01-12 14:30:40',1),(126,'SLB','00733896',5000000,'000000','SOLAR BANKING TRANSFER 5,000,000 VND at 2023-01-12','',1,'2023-01-12 14:31:19',1),(127,'00733896','90562859',100000,'360962','Transfer Money','SRC',1,'2023-01-12 14:45:01',1),(129,'00733896','90562859',200000,'520240','Transfer Money','SRC',1,'2023-01-12 14:50:36',1),(133,'00733896','48750494',150000,'986699','Transfer Money','SRC',1,'2023-01-12 14:57:43',1),(135,'00733896','71873611',50000,'709232','','SRC',1,'2023-01-12 15:32:43',2),(139,'71873611','23875338674',100000,'173712','Transfer Money SLB','SRC',1,'2023-01-12 15:55:53',1),(140,'17444489','87446423777',36000,'593486','TIen banh trang tron','SRC',1,'2023-01-01 13:05:03',1),(141,'SLB','17444489',10000000,'000000','SOLAR BANKING TRANSFER 10,000,000 VND at 2023-01-1','',1,'2023-01-13 13:07:47',1),(142,'17444489','87446423777',300000,'796040','Buffet Hana','SRC',1,'2023-01-03 13:10:34',1),(143,'17444489','44672774950',80000,'914310','2 cai banh xeo','SRC',1,'2023-01-13 13:11:19',1),(144,'81627401','59025838490',500000,'084357','Skincare 500k','SRC',1,'2023-01-08 13:14:51',1),(145,'81627401','59025838490',40000,'029670','Chao suonnnn','SRC',1,'2023-01-10 13:15:40',1),(146,'81627401','36871570986',2000000,'157836','Card D.O. Pink Christmas','SRC',1,'2023-01-13 13:18:07',1),(147,'81627401','86381372076',46000,'618815','Luckey card','SRC',1,'2023-01-13 13:19:19',1),(148,'81627401','49578221111',650000,'124423','New Balance 547','SRC',1,'2023-01-11 13:20:40',1),(149,'81627401','59025838490',15000,'918440','Tien cafe sua','SRC',1,'2023-01-05 13:21:58',1),(150,'81627401','86381372076',360000,'321915','banh trang phoi suong','SRC',1,'2023-01-03 13:23:07',1);
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_type`
--

DROP TABLE IF EXISTS `transaction_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_type` (
  `transaction_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_type_name` varchar(20) NOT NULL,
  PRIMARY KEY (`transaction_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_type`
--

LOCK TABLES `transaction_type` WRITE;
/*!40000 ALTER TABLE `transaction_type` DISABLE KEYS */;
INSERT INTO `transaction_type` VALUES (1,'Transfer'),(2,'Debt Complete');
/*!40000 ALTER TABLE `transaction_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` char(10) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (34,'Nguyen Vu Duy Khuong','duykhuong3072001@gmail.com','0903024916'),(35,'Lam Thanh Ha','hathanh@gmail.com','902334587'),(36,'Mai Ngoc Tan','tanngoc@gmail.com','944223456'),(37,'Dang Duy Khang','duykhang11@gmail.com','933462959'),(38,'Lam Hoai Khoa','khoalam1122@gmail.com','919507114'),(39,'Le Phuong Mai','lephuongmai8877@gmail.com','0988763443'),(40,'Lam Thanh Hong','hong8877@gmail.com','1902445452'),(41,'Mai Ngoc Tan','tannsdgoc@gmail.com','1902445452'),(42,'Dang Duy Khang','duysdsdkhang11@gmail.com','1902445452'),(43,'Lam Hoai Khoa','khsdsdoalam1122@gmail.com','1902445452'),(44,'Lam Thanh Ha','hathasdsdnh@gmail.com','1902445452'),(45,'Mai Ngoc Tan','tannsdsdgoc@gmail.com','1902445452'),(46,'Dang Duy Khang','duykhsdsdang11@gmail.com','1902445452'),(47,'Lam Hoai Khoa','khosdsdalam1122@gmail.com','1902445452'),(48,'Bach Tu Liem','laylala0099@gmail.com','123123'),(49,'Nguyen Manh Vu','imbachecktest@gmail.com','123123'),(50,'Vu Thi Dung','duynguyen8899@gmail.com','123123123'),(51,'Lam Hoang Tuan','hahajo@gmail.com','123123'),(52,'Nguyen Vu Duy Khuong','duykhuong3072002@gmail.com','123123123'),(53,'Mai Ngoc Khang','khang9988@gmail.com','0919507114'),(54,'Lam Hoang Minh','lamhoangminh99@gmail.com','0902212343'),(55,'Nguyen Ho Bach','hobach99@gmail.com','0988776754'),(56,'Lam Bao Ngoc','khoelvu08082001@gmail.com','0988123324'),(57,'Andrew pham','',''),(58,'Nguyen An Hung','anhung009988@gmail.com','0933442214'),(59,'Le Thanh Dat','thanh9900@gmail.com','0999887332'),(60,'Le Minh Thu','leminhthu889932@gmail.com','0908887635'),(61,'Ho Hoang Khang','khanghoang009988@gmail.com','0908776652'),(62,'Ho Hoang Khoa','khOAhoang009988@gmail.com','0908776652'),(63,'bachhoang','hoanghoang99@gmail.com','0908776652'),(64,'aaaaa','hoansdsdghoang99@gmail.com','0908776652'),(65,'asdsdsd','sdsdds@gmail.com','09090909'),(66,'asdsdsd','sdsdds@gmail.com','09090909'),(67,'asdsdsds','sdsddss@gmail.com','09090909'),(69,'Dang Duy Khang','ddk992001@gmail.com','0903024916'),(70,'Nguyen Manh Vu','vunguyenmanh28@gmail.com','0903024916'),(71,'Ho Hoang Bach','bachbach99kk@gmail.com','0903024916'),(72,'Huynh Hoang Giang','',''),(73,'Customer Name','','');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_account`
--

DROP TABLE IF EXISTS `user_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_account` (
  `user_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `user_type_id` int(11) NOT NULL,
  `last_expired_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `refresh_token` text NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `fk_useraccount_usertype` (`user_type_id`),
  CONSTRAINT `fk_useraccount_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_useraccount_usertype` FOREIGN KEY (`user_type_id`) REFERENCES `user_type` (`user_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_account`
--

LOCK TABLES `user_account` WRITE;
/*!40000 ALTER TABLE `user_account` DISABLE KEYS */;
INSERT INTO `user_account` VALUES (34,'kolgo','$2b$10$0dwBeTTqTdYSRKajJXG6Je2o.EZD/kOezO2DpK7DcucVXE.74R6Cu',2,'2023-01-14 02:29:54','84769285902375269339'),(35,'halt','$2b$10$jDrXJnRHL6VyRILszz02reW6KYw4aCKjnjCao/.bai1RVpkab8so6',1,'2023-01-14 02:29:41','72259112927729458536'),(36,'tanmg','$2b$10$wm5g16zMUQHzAHBSFUh7meh4ILLe78EmQ9bE87yfunn7ZRYvK0o62',1,'2023-01-14 02:29:41','21654984515616846313'),(37,'ddkhang','$2b$10$3.TU.Io1a6e7msbwfWOEq.3V1qnDbA9JlDRLgqQg.JW9Ayi1wCOy.',1,'2023-01-14 02:29:41','22526729701792003164'),(38,'hoaikhoa','$2b$10$I2SzewSom.IbczBtEGWeF.KPbrZRMgJ6ymQeBWI9GcE2VayUEBay6',1,'2023-01-14 02:29:41','04646026847315707163'),(39,'khuong307','$2b$10$j3LcZNyGY0WqGfd61PycBuPOoDwBR3zfdsSgZqoGQEv6rPYV/Kglm',1,'2023-01-14 02:29:41','01684127305957537671'),(40,'adas','$2b$10$c1RsqumJ2nrbML2rwYv4O.Jos92TDj/PYAx4eF8g.cN0FCQ7yVSku',1,'2023-01-14 02:29:41','23248431483148615236'),(41,'asdascx','$2b$10$jy9meNubj/oM8x5gfeUnf.PCdqnNeSTyiD5JKlCMk65BJm9IcFsfK',1,'2023-01-14 02:29:41','43674027907137100767'),(42,'xcxcx','$2b$10$IGFy7e/7LQPmmY1Zxdt/teb4tyjKUXUZHWx9tb23G9GkhK0rnDPkq',1,'2023-01-14 02:29:41','07027078735277907235'),(43,'dsds','$2b$10$Pz9BgrMenLiej47gil1YzOE2YKVzCtjVpsdyrCOuMF/pMA8zS4EY6',1,'2023-01-14 02:29:41','70275167709727307071'),(44,'aacxx','$2b$10$6h2mimTT7aCyfc6xvtqWaO9Uzs0sBrxZFLaB1aGq2VAta9yDBT7c.',1,'2023-01-14 02:29:41','04727327206707214571'),(45,'zxzxzx','$2b$10$Tx341W3I9IgzhzGQjL92qO0/8TjXr/JrsjPksD2kpsBUfTd.w23p6',1,'2023-01-14 02:29:41','31661407815761570000'),(46,'qwqw','$2b$10$oEdKlddtb7zHHd9fH5CLSOqoX4Ukx9gnqrkhtkI.Q3ZoSeaXm/JqS',1,'2023-01-14 02:29:41','19454027173179017012'),(47,'ghgjy','$2b$10$HYVnR/k71iFjdpHE.ORPKeqoRWTCPDMJXwrMLcL.thWY1Xf9ckpru',1,'2023-01-14 02:29:41','31452572797237752444'),(48,'sdsdsdsd','$2b$10$scGiEXMddhR77toGlPEkF.4HzD1EBM2GMQT1KNd.rVV9MSwi97JkW',1,'2023-01-14 02:29:41','68927202526882757255'),(49,'kakapro007','$2b$10$E3H/HpCh5K34rWLuvyu.culpRyIVMSCqlmQV.IqXmvx8n1CEXNkvO',1,'2023-01-14 02:29:41','06282879625268276628'),(50,'duynguyen','$2b$10$4waN9xVs5dhrTHCWApXCDeWDJaxl6xs5VYJ/IBLC4Yn8UVT1muPfK',1,'2023-01-14 02:29:41','29276827648729386784'),(51,'tuanlamjj','$2b$10$Q59SuaX/1q21ART6YNiCTukR4cyxRKfk22YmtN.yQTYqehIPMQIOm',1,'2023-01-14 02:29:41','52787629852967498624'),(52,'kolgo2','$2b$10$OTl.GToumW8GYCLiBlrNG.GGhRZexPJEQh0BtusFuWv48QONwO/hS',1,'2023-01-14 02:29:41','20509269768768484674'),(53,'khangmm','$2b$10$v7s6RAuP9KJtvfd5s34CAu9pjOtTCU.JeS45Q6Z16eOs3K9vhXaUS',1,'2023-01-14 02:29:41','68726283589328484844'),(54,'minh99hoang','$2b$10$UPNsf2px3AJn8if2e.xT..UdnZChCRFJ.q6bF6hSqJjJlT6SuBahi',1,'2023-01-14 02:29:41','26782276289525728354'),(55,'bach','$2b$10$G2Yy1Ez6eOuhTotP4rkDEugAwMev5yemiUxl2zSbDgGBWDyV3wyOu',1,'2023-01-14 02:29:41','45645645640404672174'),(56,'ngoclam','$2b$10$CYM05qNz5ggL6kC01jekDODLjGfDBy8XARx6uncRX3fbqTGxK2cLS',1,'2023-01-12 16:45:22','49833537959583421775'),(58,'nyl','$2b$10$qkebC2biDUttoTWJ.njG0uhBu3CkgSCxcWyY7D6fTK2oIcuXPumDa',1,'2023-01-13 14:10:20','04854972213497015007'),(59,'thanhdat','$2b$10$Ln8g/xlC.DD4Yta/1B01Oe9PSVUnxe7X1EOA0GzY2IU4cB10oqeHu',3,'2023-01-13 14:24:17','65798188325743666344'),(60,'thule','$2b$10$d0VvmoEIfI.1I8/fCqyqGuZ.SJFnHE4FCg3lEv4la0BE2cEGCf0Fu',1,'2023-01-09 12:01:12','81233592856303812468'),(61,'hoangka','$2b$10$.ssLyidQwbkG1GdnoYsuOuN6q27MWVKc9EeOKhLTTwHAXISzU7mAK',2,'2023-01-10 14:03:44','63550857915162786500'),(62,'hoangkhoa','$2b$10$1Fs/tpwx61iha5NTCGeR3.fawlHIANptyC7RlWyGqvGNLYFn9W4Vu',2,'2023-01-10 14:04:28','72259112927729458518'),(63,'kakajjjjhh','$2b$10$b5v5JHfRkHSuGeEMKFuGWup9fy2yi0Fim0fXTDvPyOhTPJ9C5YQGe',2,'2023-01-10 14:06:36','56746353951408080353'),(64,'kakajjjjhhsdsd','$2b$10$hUPxm4JD7a77G1UvtI5pkuPH5GBLal5lurpG7HmkSbNd3Yo47Z.5C',2,'2023-01-10 14:08:58','50967445415039530753'),(65,'sssssss','$2b$10$0WwBz2qyEcvGWU1HbJ3xmutju7NXpIeZt06I7.Z3N8O.vL/1sEwQS',2,'2023-01-10 14:10:42','53157308999377678864'),(66,'sssssss','$2b$10$XWCX/L8tZz7c0yHRZ/82OuxamCmC0fA8rD5ninDq3rwzS5Lf1a1TK',2,'2023-01-10 14:11:21','81786686713529800626'),(67,'ssssssss','$2b$10$S9IDSvl6Bev9J6uH6qd9LuidBQFdnzx3L3jL/kS3EOSYN6cco8WWi',2,'2023-01-10 14:11:30','49764702250131168335'),(69,'duykhang','$2b$10$BjB55hz0coqE/78Rv5Y6M.6UAyIG.FvDcB4t/7mJ3ggWWNVMijLFG',1,'2023-01-11 14:06:33','56386048480885252993'),(70,'manhvu0099','$2b$10$E7AJVCS0EV1jLmfy7ChUNe9lXFeMQgbGtlQsmxoUeapbiDHyumC5K',1,'2023-01-12 16:27:55','42597044359676173221'),(71,'bachho','$2b$10$61vx9cfiWegXmIwTYU0pIOI/1SmH93FkWpHpcCstNoOFbTOelP87G',1,'2023-01-12 16:17:08','55250133073656943309');
/*!40000 ALTER TABLE `user_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_type`
--

DROP TABLE IF EXISTS `user_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_type` (
  `user_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type_name` varchar(20) NOT NULL,
  PRIMARY KEY (`user_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_type`
--

LOCK TABLES `user_type` WRITE;
/*!40000 ALTER TABLE `user_type` DISABLE KEYS */;
INSERT INTO `user_type` VALUES (1,'Customer'),(2,'Employee'),(3,'Admin');
/*!40000 ALTER TABLE `user_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'final_solarbanking'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-14  9:35:17
